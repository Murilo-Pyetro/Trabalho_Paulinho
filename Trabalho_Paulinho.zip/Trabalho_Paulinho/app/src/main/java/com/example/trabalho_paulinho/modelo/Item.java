package com.example.trabalho_paulinho.modelo;

import android.widget.TextView;

public class Item {

     String Descricao;

     String Codigo;
     Double ValUnitario;



    public Item() {
    }

    public Item(String descricao, String codigo, Double valUnitario) {
        Descricao = descricao;
        Codigo = codigo;
        ValUnitario = valUnitario;
    }

    public String getDescricao() {
        return Descricao;
    }

    public void setDescricao(String descricao) {
        Descricao = descricao;
    }

    public String getCodigo() {
        return Codigo;
    }

    public void setCodigo(String codigo) {
        Codigo = codigo;
    }

    public Double getValUnitario() {
        return ValUnitario;
    }

    public void setValUnitario(Double valUnitario) {
        ValUnitario = valUnitario;
    }
}



