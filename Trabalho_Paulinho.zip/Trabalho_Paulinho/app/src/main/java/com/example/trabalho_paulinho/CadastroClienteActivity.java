package com.example.trabalho_paulinho;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.trabalho_paulinho.modelo.Cliente;

public class CadastroClienteActivity extends AppCompatActivity {

    private EditText edNomeCliente;

    private EditText edCpfCliente;

    private Button btSalvarCliente;

    private TextView tvClientesCadastrados;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_cliente);

        edNomeCliente = findViewById(R.id.edNomeCliente);
        edCpfCliente = findViewById(R.id.edCpfCliente);
        btSalvarCliente = findViewById(R.id.btSalvarCliente);
        tvClientesCadastrados = findViewById(R.id.tvClientesCadastrados);

        atualizarListaClientes();

        btSalvarCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarCliente();
            }
        });
    }

    private void salvarCliente() {

        if (edNomeCliente.getText().toString().isEmpty()) {
            edNomeCliente.setError("Informe o Nome do Cliente!");
            return;
        }
        if (edCpfCliente.getText().toString().isEmpty()) {
            edCpfCliente.setError("Informe o CPF do Cliente!");
            return;
        }

        Cliente cliente = new Cliente();
        cliente.setNome(edNomeCliente.getText().toString());
        cliente.setCpf(edCpfCliente.getText().toString());

        Controller.getInstance().salvarClientes(cliente);

        Toast.makeText(CadastroClienteActivity.this,
                "Cliente Cadastrado com sucesso", Toast.LENGTH_LONG).show();

        this.finish();
    }

    private void atualizarListaClientes() {
        String texto = "";
        for (Cliente cliente : Controller.getInstance().retornarClientes()) {
            texto += texto + "Nome: " + cliente.getNome() +
                    " \n Cpf: " + cliente.getCpf() + "\n";
        }
        tvClientesCadastrados.setText(texto);
    }
}