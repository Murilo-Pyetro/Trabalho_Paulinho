package com.example.trabalho_paulinho;

import androidx.appcompat.app.AppCompatActivity;

import android.net.eap.EapSessionConfig;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.trabalho_paulinho.modelo.Cliente;
import com.example.trabalho_paulinho.modelo.Item;
import com.example.trabalho_paulinho.modelo.Pedido;

import java.util.ArrayList;
import java.util.Random;

public class LancamentoPedidoActivity extends AppCompatActivity {

;

    private ImageButton btAddPagamentoAprazo;

    private LinearLayout lnexibeAvsita;

    private LinearLayout lnexibeAprazo;
    private EditText edIndicaParcelas;
    private TextView tvAprazo;

    private TextView tvAvista;

    private ImageButton btAddPedido;
    private TextView tvRetornaCodPedido;
    private Spinner spEscCliente;
    private Spinner spEscIten;
    private EditText edQuantidadeItens;
    private TextView tvValUnitario;
    private Button btFinalizarPedido;
    private TextView tvErroCliente;
    private TextView tvErroItem;
    private TextView tvDescricaoItens;
    private TextView tvTotalItens;
    private TextView tvListaValorTotal;
    private RadioGroup rgSistema;
    private RadioButton rbAvista;
    private RadioButton rbAprazo;
    private ArrayList<Cliente> listaClientes;
    private ArrayList<Item> listaitens;
    private int posicaoSelecionada = 0;
    private int posicaoItemSelecionada = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lancamento_pedido);

        spEscCliente = findViewById(R.id.spEscCliente);
        spEscIten = findViewById(R.id.spEscIten);
        edQuantidadeItens = findViewById(R.id.edQuantidadeItens);
        tvValUnitario = findViewById(R.id.tvValUnitario);
        btFinalizarPedido = findViewById(R.id.btFinalizarPedido);
        tvErroCliente = findViewById(R.id.tvErroCliente);
        tvErroItem = findViewById(R.id.tvErroItem);
        tvDescricaoItens = findViewById(R.id.tvDescricaoItens);
        tvTotalItens =  findViewById(R.id.tvTotalItens);
        tvListaValorTotal = findViewById(R.id.tvListaValorTotal);
        rgSistema = findViewById(R.id.rgSistema);
        rbAprazo = findViewById(R.id.rbAprazo);
        rbAvista = findViewById(R.id.rbAvista);
        tvRetornaCodPedido = findViewById(R.id.tvRetornaCodPedido);
        btAddPedido = findViewById(R.id.btAddPedido);
        tvAvista = findViewById(R.id.tvAvista);
        lnexibeAvsita = findViewById(R.id.lnexibeAvsita);
        lnexibeAprazo = findViewById(R.id.lnexibeAprazo);
        edIndicaParcelas = findViewById(R.id.edIndicaParcelas);
        tvAprazo = findViewById(R.id.tvAprazo);
        btAddPagamentoAprazo = findViewById(R.id.btAddPagamentoAprazo);




        rgSistema.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {


            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int posicao) {
                if (posicao == rbAvista.getId()){

                    posicaoSelecionada = posicao;
                    lnexibeAvsita.setVisibility(View.VISIBLE);
                    ExibeAvista();



                }else if (posicao == rbAprazo.getId()){

                    int valores;

                    posicaoSelecionada = posicao;
                    lnexibeAprazo.setVisibility(View.VISIBLE);


                }
            }
        });


        spEscCliente.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int posicao, long l) {
                if (posicao > 0){
                    tvErroCliente.setVisibility(View.GONE);
                    posicaoSelecionada = posicao;

                }
            }
            
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        
        spEscIten.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int posicao2, long l) {
                if (posicao2 > 0){
                    tvErroItem.setVisibility(View.GONE);
                    posicaoItemSelecionada = posicao2;
                    exibeValorUnitario();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        
        btFinalizarPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               tvAprazo.setText("");
               tvAvista.setText("");
               tvDescricaoItens.setText("");;
               tvErroCliente.setText("");
               tvErroItem.setText("");
               tvListaValorTotal.setText("");;
               tvRetornaCodPedido.setText("");
               tvTotalItens.setText("");
               tvValUnitario.setText("");
               edQuantidadeItens.setText("");
               edIndicaParcelas.setText("");
               lnexibeAvsita.setVisibility(View.GONE);
               lnexibeAprazo.setVisibility(View.GONE);
            }
        });


        btAddPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarPedido();
                atualizaDescricaoPedido();
                QtdItensAdicionados();
                ValorTotal();

            }
        });

        btAddPagamentoAprazo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvaPagamento();
                ExibeAprazo();
            }
        });



        carregaClientes();
        carregaItens();
        gerarCodigoPedido();


    }

    private void gerarCodigoPedido() {
        int codigo = new Random().nextInt(10000);
        tvRetornaCodPedido.setText(" Código do pedido - " + codigo);
    }

    private void salvarPedido() {

        double qtdItens;

        if (edQuantidadeItens.getText().toString().isEmpty()) {
            edQuantidadeItens.setError(" Informe a quantidade de itens! ");
            edQuantidadeItens.requestFocus();
            return;
        } else {
            qtdItens = Double.parseDouble(edQuantidadeItens.getText().toString());
            if (qtdItens <= 0) {
                edQuantidadeItens.setError(" A quantidade de itens deve ser maior que zero! ");
                edQuantidadeItens.requestFocus();
                return;
            }
        }
        if (posicaoSelecionada == 0){
            tvErroCliente.setVisibility(View.VISIBLE);
            return;
        }
        if (posicaoSelecionada == 0 ){
            tvErroItem.setVisibility(View.VISIBLE);
            return;
        }

        Cliente cliente = listaClientes.get(posicaoSelecionada - 1);
        Item item = listaitens.get(posicaoSelecionada - 1);

        Pedido pedido = new Pedido();
        pedido.setQuantidade(Integer.parseInt(edQuantidadeItens.getText().toString()));
        pedido.setCliente(cliente);
        pedido.setItem(item);

        Controller.getInstance().adicionarPedido(pedido);
        Toast.makeText(this, "Pedido salvo com Sucesso!. " + item.getCodigo(), Toast.LENGTH_SHORT).show();

    }

    private void salvaPagamento(){

        double qtdParcelas;

        if (edIndicaParcelas.getText().toString().isEmpty()) {
            edIndicaParcelas.setError(" Informe a quantidade de parcelas! ");
            edIndicaParcelas.requestFocus();
            return;
        } else {
            qtdParcelas = Double.parseDouble(edIndicaParcelas.getText().toString());
            if (qtdParcelas <= 0) {
                edIndicaParcelas.setError(" A quantidade de parcelas deve ser maior que zero! ");
                edIndicaParcelas.requestFocus();
                return;
            }
            if (qtdParcelas > 12){
                edIndicaParcelas.setError(" A quantidade máxima de parcelas disponiveis é 12! ");
                edIndicaParcelas.requestFocus();
                return;
            }
        }

        Pedido pagamento = new Pedido();
        pagamento.setParcelas(Integer.parseInt(edIndicaParcelas.getText().toString()));

        Controller.getInstance().salvarPagamento(pagamento);

    Toast.makeText(this, "Pagamento Salvo com sucesso!", Toast.LENGTH_SHORT).show();


    }

    private void carregaClientes() {
        listaClientes = Controller.getInstance().retornarClientes();
        String[] vetClientes = new String[listaClientes.size() + 1];
        vetClientes[0] = " Selecione o Cliente";
        for (int i = 0; i <listaClientes.size(); i++) {
            Cliente cliente = listaClientes.get(i);
            vetClientes[i + 1] = cliente.getNome() + " - " + cliente.getCpf();
        }
        ArrayAdapter adapter = new ArrayAdapter(
                LancamentoPedidoActivity.this,
                android.R.layout.simple_dropdown_item_1line,
                vetClientes);

        spEscCliente.setAdapter(adapter);
    }

    private void carregaItens() {
        listaitens = Controller.getInstance().retornarItens();
        String[] vetItens = new String[listaitens.size() + 1];
        vetItens[0] = " Selecione o Item";
        for (int i = 0; i <listaitens.size(); i++) {
            Item item = listaitens.get(i);
            vetItens[i + 1] = item.getCodigo();
        }
        ArrayAdapter adapter = new ArrayAdapter(
                LancamentoPedidoActivity.this,
                android.R.layout.simple_dropdown_item_1line,
                vetItens);

        spEscIten.setAdapter(adapter);
    }

    private void atualizaDescricaoPedido() {
        ArrayList<Pedido> lista = Controller.getInstance().retornarPedidos();

        String texto = "";

        for (Pedido dis : lista) {
            Item item = dis.getItem();
            Cliente cliente = dis.getCliente();
            texto += "Cliente: " + cliente.getNome() + "\n" +
                    "Código: " + item.getCodigo()+ "\n" +
                    "Descrição: " + item.getDescricao();
        }
//          nomecli = lista.get(posicaoItemSelecionada).getCliente().getNome().toString();
//          coditem = lista.get(posicaoItemSelecionada).getItem().getCodigo().toString();
//          descitem = lista.get(posicaoItemSelecionada).getItem().getDescricao().toString();
//         texto = "Nome: "+ nomecli + "\n" +
//                 "Cod: " +coditem + "\n" +
//                 "Descricao "+descitem;

         tvDescricaoItens.setText(texto);
    }


    private void exibeValorUnitario() {

        ArrayList<Item> lista = Controller.getInstance().retornarItens();
        String exibeValorUni = "";
        for (Item dis: lista) {
            exibeValorUni = lista.get(posicaoItemSelecionada - 1).getValUnitario() + " R$";

        }

           tvValUnitario.setText(exibeValorUni);
    }

    private void QtdItensAdicionados(){
        ArrayList<Pedido> lista = Controller.getInstance().retornarPedidos();
        String QtdItens = "";
        for (Pedido dis: lista) {

            QtdItens = " Quantidade de Itens Adicionados: " + lista.get(posicaoItemSelecionada - 1).getQuantidade();
        }
        tvTotalItens.setText(QtdItens);
    }
    private void ValorTotal(){

        ArrayList<Pedido> lista = Controller.getInstance().retornarPedidos();
        String ValTotal = "";
        for (Pedido dis: lista) {
            Item item = dis.getItem();
            ValTotal += dis.getQuantidade() * item.getValUnitario();

        }

        tvListaValorTotal.setText(ValTotal);

    }
    private void ExibeAvista(){
        ArrayList<Pedido> lista = Controller.getInstance().retornarPedidos();
        String exibe1= "";
        String exibe2 = "";

        for (Pedido dis: lista) {
            Item item = dis.getItem();
           exibe1 += ((dis.getQuantidade() * item.getValUnitario()) * 0.05);
           exibe2 += ((dis.getQuantidade() * item.getValUnitario()) - Double.parseDouble(exibe1)) + "R$";

        }
        tvAvista.setText(exibe2);
    }

    private void ExibeAprazo(){
        ArrayList<Pedido> lista = Controller.getInstance().retornarPedidos();
        double valorJuros = 0.0;
        double exibeParcelas = 0.0;
        for (Pedido dis: lista) {
            Item item = dis.getItem();
            valorJuros = ((dis.getQuantidade() * item.getValUnitario()) );

        }
        valorJuros = valorJuros+ ( valorJuros *0.05);
        exibeParcelas = valorJuros / Integer.parseInt(edIndicaParcelas.getText().toString());

        tvAprazo.setText(edIndicaParcelas.getText().toString() + " x R$"+exibeParcelas);

    }


}