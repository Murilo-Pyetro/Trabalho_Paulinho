package com.example.trabalho_paulinho;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.trabalho_paulinho.modelo.Item;

import java.util.Random;

public class CadastroItensActivity extends AppCompatActivity {

    private TextView tvRetornaCod;
    private EditText edDescIten;
    public EditText edValUnitario;
    private Button btSalvarItens;
    private TextView tvItensCadastrados;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_itens);

        tvRetornaCod = findViewById(R.id.tvRetornaCod);
        edDescIten = findViewById(R.id.edDescIten);
        edValUnitario = findViewById(R.id.edValUnitario);
        btSalvarItens = findViewById(R.id.btSalvarItens);
        tvItensCadastrados = findViewById(R.id.tvItensCadastrados);



        btSalvarItens.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarItem();
            }
        });

        atualizarListaItens();
        gerarCodigo();


    }

    private void gerarCodigo() {
        int codigo = new Random().nextInt(10000);
        tvRetornaCod.setText( " Código do cadastro - " + codigo);
    }
    private void salvarItem() {

        double valorUnitario;

        if (tvRetornaCod.getText().toString().isEmpty()) {
            tvRetornaCod.setError("Clique no Botão para gerar o Código!");
            return;
        }
        if (edDescIten.getText().toString().isEmpty()) {
            edDescIten.setError("Informe a Descrição do item!");
            return;
        }
        if (edValUnitario.getText().toString().isEmpty()) {
            edValUnitario.setError(" Informe o valor do item! ");
            edValUnitario.requestFocus();
            return;
        } else {
            valorUnitario = Double.parseDouble(edValUnitario.getText().toString());
            if (valorUnitario <= 0) {
                edValUnitario.setError(" O valor do Item deve ser maior que zero! ");
                edValUnitario.requestFocus();
                return;
            }
        }

        Item item = new Item();
        item.setCodigo(tvRetornaCod.getText().toString());
        item.setDescricao(edDescIten.getText().toString());
        item.setValUnitario(Double.parseDouble(edValUnitario.getText().toString()));

        Controller.getInstance().salvarItens(item);
        Toast.makeText(CadastroItensActivity.this,
                "Item Cadastrado com sucesso. "+ item.getCodigo(), Toast.LENGTH_LONG).show();

        this.finish();
    }
    private void atualizarListaItens() {
        String texto = "";
        for (Item item : Controller.getInstance().retornarItens()) {
            texto = texto  + item.getCodigo() +
                    " \n Descrição: " + item.getDescricao() +
                    " \n Valor Unitário: " + item.getValUnitario() + "R$" + "\n"
                    ;
        }
        tvItensCadastrados.setText(texto);

    }
}