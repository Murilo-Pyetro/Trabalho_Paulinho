package com.example.trabalho_paulinho.modelo;

public class Pedido {

     int Quantidade;

     int Parcelas;



    Cliente cliente;
    Item item;


    public Pedido() {
    }

    public Pedido(int quantidade, int parcelas, Cliente cliente, Item item) {
        Quantidade = quantidade;
        Parcelas = parcelas;
        this.cliente = cliente;
        this.item = item;
    }

    public int getQuantidade() {
        return Quantidade;
    }

    public void setQuantidade(int quantidade) {
        Quantidade = quantidade;
    }

    public int getParcelas() {
        return Parcelas;
    }

    public void setParcelas(int parcelas) {
        Parcelas = parcelas;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }
}
