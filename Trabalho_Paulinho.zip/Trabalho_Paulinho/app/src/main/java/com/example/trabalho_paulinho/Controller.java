package com.example.trabalho_paulinho;

import com.example.trabalho_paulinho.modelo.Cliente;
import com.example.trabalho_paulinho.modelo.Item;
import com.example.trabalho_paulinho.modelo.Pedido;

import java.util.ArrayList;

public class Controller {

    private static Controller instancia;

    private ArrayList<Cliente> listaClientes;
    private ArrayList<Item> listaItens;

    private ArrayList<Pedido> listaPedido;

    private ArrayList<Pedido> listaPagamento;

    public static Controller getInstance(){
        if (instancia == null)
            return instancia = new Controller();

        else
            return instancia;
    }
    private Controller(){

        listaPedido = new ArrayList<>();
        listaClientes =  new ArrayList<>();
        listaItens = new ArrayList<>();
        listaPagamento = new ArrayList<>();
    }

    public void salvarClientes(Cliente cliente){
        listaClientes.add(cliente);
    }
    public  ArrayList<Cliente> retornarClientes(){
        return  listaClientes;
    }
    public void adicionarPedido(Pedido pedido){
        listaPedido.add(pedido);
    }
    public  ArrayList<Pedido> retornarPedidos(){
        return  listaPedido;
    }
    public void salvarItens(Item item){
        listaItens.add(item);
    }
    public  ArrayList<Item> retornarItens(){
        return  listaItens;
    }

   public void salvarPagamento(Pedido pagamento){listaPagamento.add(pagamento);}
    public ArrayList<Pedido> retornaPagamento(){
        return  listaPagamento;
    }



}
